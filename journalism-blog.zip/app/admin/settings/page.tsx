export default function Settings() {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Site Settings</h2>
      <p className="text-sm text-slate-600">You can edit site title, description and theme from here (future improvement).</p>
    </div>
  )
}
